angular.module('citizen-engagement')
  .constant('apiUrl', 'https://comem-citizen-engagement-2017i.herokuapp.com/api')
  .constant('mapboxSecret', 'pk.eyJ1Ijoibm9vcyIsImEiOiJjajBkazFoM2swMDBnMzNvNGE4ZzVzOGF5In0.ySgDGeU9i1NHshRz0SLX2w')
  .constant('qimgUrl', 'https://comem-qimg.herokuapp.com/api')
  .constant('qimgSecret', 'DykrFXirzTk50eoXg6c84Nbc7GcNd4xpwrgeM4ynVgAC8aof6HRL0IZSta/yLrJN4JAuFhGbAXslbhexPtCPvvEQtGLqBIGn2CCHfAMpMj0RokzWusuwsSVgEHo2T+sh3syBGqnPmSJJCjkV+V0s5OlnBlABq9xx8kl0DYGOPNQ=')
;
